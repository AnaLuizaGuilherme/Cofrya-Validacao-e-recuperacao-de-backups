# Cofrya — pacote completo de testes C0 a C7

Oito cenários com dados sintéticos, semente **1** e **1.000 pedidos**, reunidos dos pacotes C0–C4 e C5–C7. Cada cenário contém `.dump`, `.manifest.json` e `.referencias.json`: **24 arquivos de entrada**, reutilizados nas quatro configurações para **32 combinações esperadas**.

## Executar no Streamlit

1. Extraia o ZIP no computador. Abra https://cofrya.streamlit.app e entre na sua conta.
2. Acesse **Backups PostgreSQL → Nova verificação** e escolha **Enviar agora pelo navegador**.
3. Abra uma pasta, por exemplo `C0`, e envie os arquivos dessa mesma pasta nos campos Backup, Manifesto e Referências. **Não envie o ZIP no campo de backup.**
4. Mantenha **Usar o nome do backup como ID da cópia** ativado. Se informar manualmente, use `pedidos_seed1_c0` para C0, seguindo o mesmo padrão até `pedidos_seed1_c7`.
5. Escolha o cenário correspondente, **Semente = 1** e **Idade máxima = 30 dias**.
6. Execute as configurações **A**, **B**, **C_sem_func** e **C**, uma por vez, com os mesmos arquivos. C exige referências.
7. Para C_sem_func e C na hospedagem, selecione **Neon** em Parâmetros adicionais. Deixe **Papéis necessários** vazio no ensaio principal, especialmente em C5.
8. Confira a decisão e a causa nas evidências; exporte os resultados das novas tentativas.

O servidor precisa da mesma chave de laboratório que assinou os manifestos, em `TCC_HMAC_KEY`. **A chave não está no pacote nem nesta documentação.** A autora já utiliza essa chave no trabalho; outra implantação deve recebê-la por canal privado ou gerar seus próprios artefatos com sua própria chave.

## O que cada configuração verifica

- **A:** existência do dump e do manifesto.
- **B:** A mais autenticação HMAC, identidade, idade, tamanho e SHA-256.
- **Restauração sem validação funcional (C_sem_func):** B mais restauração nativa em ambiente temporário.
- **C:** C_sem_func mais presença de tabelas, contagens e totalização dos pedidos.

Selecionar o cenário na interface apenas rotula a tentativa. A falha já está preparada nos arquivos; não é injetada pelo seletor.

## Matriz esperada

| Cenário | A | B | C_sem_func | C |
| --- | --- | --- | --- | --- |
| C0 — Backup válido | Aprovada | Aprovada | Aprovada | Aprovada |
| C1 — Arquivo truncado | Aprovada | Reprovada | Reprovada | Reprovada |
| C2 — Byte alterado | Aprovada | Reprovada | Reprovada | Reprovada |
| C3 — Tabela pagamentos omitida | Aprovada | Aprovada | Aprovada | Reprovada |
| C4 — Total de pedido incorreto | Aprovada | Aprovada | Aprovada | Reprovada |
| C5 — Papel ausente no destino | Aprovada | Aprovada | Reprovada | Reprovada |
| C6 — Manifesto com captura simulada antiga | Aprovada | Reprovada | Reprovada | Reprovada |
| C7 — Adulteração sem HMAC válido | Aprovada | Reprovada | Reprovada | Reprovada |

`matriz_esperada.csv` apresenta as 32 combinações e suas causas esperadas. Aprovação é relativa às etapas habilitadas. A e B não demonstram restauração; C_sem_func não demonstra correção funcional.

## Condições para reproduzir os cenários

- Use a chave correta e mantenha juntos os três arquivos de cada pasta. Não gere um novo manifesto pela aba Proteger e não altere datas ou hashes: isso pode eliminar a falha planejada em C1, C2 ou C7.
- C3 omite a definição e os dados de `public.pagamentos`; C4 modifica `total_declarado` do pedido 1. As referências foram capturadas antes das falhas.
- C5 preserva comandos `GRANT` para `papel_leitura_restrita`. O papel precisa estar **ausente** no destino; branches Neon podem herdá-lo do pai. Use um projeto de laboratório compatível com essa condição. Preparar esse papel é um controle positivo separado, cuja aprovação é esperada, e descaracteriza o ensaio principal C5.
- C6 tem captura **simulada 400 dias no passado**, assinada antes da verificação. O limite esperado é 30 dias. O arquivo não foi realmente armazenado por 400 dias.
- C7 tem um byte adulterado e hash público atualizado, mas HMAC inválido. Sua reprovação deve ocorrer na autenticação.
- Os manifestos dos demais cenários datam de **23 ou 24/09/2026**. Depois de 30 dias, a política temporal também pode rejeitá-los. Para uma nova coleta, gere novos artefatos de forma controlada, preservando o desenho de cada cenário; não apresente este pacote histórico como uma captura recente.
- Os dumps foram produzidos por **pg_dump 17.9**. Utilize cliente `pg_restore` 17 ou superior e servidor compatível; no laboratório, PostgreSQL 17 ou superior. C_sem_func e C exigem ambiente temporário configurado, clientes PostgreSQL e credenciais do provedor.
- Uma reprovação por chave, versão ou conexão diferente da causa preparada não confirma o cenário. Ausência de referências ou ambiente pode impedir a execução ou resultar em inconclusão.

## Conteúdo e rastreabilidade

- `C0/` a `C7/`: 24 arquivos de entrada, com bytes idênticos aos dois pacotes de origem.
- `matriz_esperada.csv`: expectativas das 32 combinações, não resultados de novas execuções.
- `proveniencia.json`: hashes dos dois ZIPs de origem, metadados de geração e inventário dos arquivos de entrada.
- `SHA256SUMS.txt`: hashes para conferir a integridade desta distribuição, inclusive dos dumps intencionalmente defeituosos. Este inventário não substitui os hashes nos manifestos.

A unificação não executou novamente restaurações e não altera os resultados históricos do TCC. A matriz consolidada do trabalho contém 31 observações; **C7/C_sem_func continua sem registro**, embora sua expectativa esteja documentada aqui. Os logs de verificações locais dos pacotes anteriores não são medições no Neon nem foram tratados como novas observações do TCC.

Código e documentação: https://github.com/AnaLuizaGuilherme/Cofrya-Validacao-e-recuperacao-de-backups
